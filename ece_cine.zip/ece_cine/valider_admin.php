<?php
session_start();
require_once "config.php";

// 🔒 Vérification que l'utilisateur est Admin
if (!isset($_SESSION['user']['id']) || ($_SESSION['user']['role'] ?? '') !== 'Admin') {
    header("Location: login.php");
    exit();
}

$message_success = null;
$message_error   = null;

// ✅ Traitement des actions (valider / rejeter)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'], $_POST['user_id'])) {
        $user_id = (int) $_POST['user_id'];
        $action  = $_POST['action'];

        try {
            if ($action === 'valider') {
                // 🔹 Valider l'inscription d'un administratif en attente
                $sql = "UPDATE utilisateur
                        SET valide = 1
                        WHERE id = ? AND role = 'Administratif' AND valide = -1";
                $stmt = $conn->prepare($sql);
                $ok = $stmt->execute([$user_id]);

                $message_success = $ok && $stmt->rowCount() > 0
                    ? "Inscription administratif validée avec succès ✅"
                    : "⚠️ Aucune ligne mise à jour (vérifie que l'utilisateur est bien 'Administratif' et en attente).";

            } elseif ($action === 'rejeter') {
                // 🔹 Supprimer le compte uniquement s'il est encore en attente
                $sql = "DELETE FROM utilisateur
                        WHERE id = ? AND role = 'Administratif' AND valide = -1";
                $stmt = $conn->prepare($sql);
                $ok = $stmt->execute([$user_id]);

                $message_success = $ok && $stmt->rowCount() > 0
                    ? "Inscription administratif rejetée ❌ et supprimée de la base."
                    : "⚠️ Aucune suppression effectuée (peut-être déjà validé ou rôle différent).";
            }
        } catch (PDOException $e) {
            $message_error = "Erreur SQL : " . htmlspecialchars($e->getMessage());
        }
    }
}

// ✅ Récupérer les inscriptions d'administratifs en attente
try {
    $sql = "SELECT id, nom, prenom, pseudo, email, date_naissance, date_inscription
            FROM utilisateur
            WHERE role = 'Administratif' AND valide = -1
            ORDER BY date_inscription ASC";
    $stmt = $conn->query($sql);
    $pending_admins = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
} catch (PDOException $e) {
    $pending_admins = [];
    $message_error = "Erreur lors du chargement des demandes : " . htmlspecialchars($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Validation Administratifs - ECE Ciné</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)),
                        url('https://i.pinimg.com/474x/27/da/97/27da97815c0c6f03d457d4158095d014--cinema-party-home-movies.jpg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            color: white;
        }
        .admin-header { background: rgba(4, 4, 4, 0.9); padding: 20px 0; margin-bottom: 30px; backdrop-filter: blur(10px); }
        .validation-card { background: rgba(255,255,255,0.95); border-radius: 15px; padding: 25px; margin-bottom: 20px; color: #333; box-shadow: 0 10px 30px rgba(0,0,0,0.3); transition: transform 0.3s ease; }
        .validation-card:hover { transform: translateY(-5px); }
        .user-info { border-left: 4px solid #0b0a0bff; padding-left: 15px; margin-bottom: 20px; }
        .btn-validate { background: linear-gradient(45deg, #28a745, #20c997); border: none; color: white; padding: 10px 25px; border-radius: 25px; transition: all 0.3s ease; }
        .btn-validate:hover { transform: scale(1.05); box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4); }
        .btn-reject { background: linear-gradient(45deg, #080707ff, #000000ff); border: none; color: white; padding: 10px 25px; border-radius: 25px; transition: all 0.3s ease; }
        .btn-reject:hover { transform: scale(1.05); box-shadow: 0 5px 15px rgba(220, 53, 69, 0.4); }
        .alert-success { background: rgba(40, 167, 69, 0.9); border: none; border-radius: 10px; color: white; }
        .alert-danger { background: rgba(10, 9, 9, 0.9); border: none; border-radius: 10px; color: white; }
        .empty-state { text-align: center; padding: 60px 20px; background: rgba(255,255,255,0.1); border-radius: 15px; backdrop-filter: blur(10px); }
        .badge-pending { background: linear-gradient(45deg, #ffc107, #fd7e14); color: #000; font-size: 0.9em; padding: 8px 15px; border-radius: 20px; }
        .back-button { background: rgba(108,117,125,0.9); border: none; color: white; padding: 12px 25px; border-radius: 25px; text-decoration: none; transition: all 0.3s ease; display: inline-block; margin-bottom: 20px; }
        .back-button:hover { background: rgba(108,117,125,1); color: white; transform: translateX(-5px); text-decoration: none; }
        .stats-card { background: rgba(255,255,255,0.1); border-radius: 10px; padding: 20px; text-align: center; backdrop-filter: blur(10px); }
        .admin-badge { background: linear-gradient(45deg, #6f42c1, #e83e8c); color: white; font-size: 0.8em; padding: 5px 10px; border-radius: 15px; margin-left: 10px; }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1><i class="fas fa-user-shield"></i> Validation des Administratifs</h1>
                    <p class="mb-0">Gestion des demandes d'inscription des administratifs ECE Ciné</p>
                    <small>Connecté en tant que :
                        <?php echo htmlspecialchars($_SESSION['user']['prenom'] . ' ' . $_SESSION['user']['nom']); ?>
                        <span class="admin-badge">Admin</span>
                    </small>
                </div>
                <div class="col-md-4 text-end">
                    <div class="stats-card">
                        <h3><?php echo isset($pending_admins) ? count($pending_admins) : 0; ?></h3>
                        <small>En attente</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <a href="admin.php" class="back-button">
            <i class="fas fa-arrow-left"></i> Retour au tableau de bord
        </a>

        <?php if (!empty($message_success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i> <?php echo $message_success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($message_error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle"></i> <?php echo $message_error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($pending_admins)): ?>
            <div class="empty-state">
                <i class="fas fa-inbox fa-4x mb-4" style="opacity: 0.5;"></i>
                <h3>Aucune demande en attente</h3>
                <p>Il n'y a actuellement aucune inscription d'administratif à valider.</p>
                <p><small>Les nouvelles demandes d'inscription administratif apparaîtront ici.</small></p>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($pending_admins as $admin): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="validation-card">
                            <div class="text-center mb-3">
                                <i class="fas fa-user-tie fa-3x text-primary mb-2"></i>
                                <h5 class="card-title mb-0">
                                    <?php echo htmlspecialchars($admin['pseudo'] ?: ($admin['nom'] ?? '')); ?>
                                </h5>
                                <span class="badge-pending">
                                    <i class="fas fa-clock"></i> En attente
                                </span>
                            </div>

                            <div class="user-info">
                                <p><strong><i class="fas fa-id-card"></i> Nom complet :</strong><br>
                                <?php echo htmlspecialchars(($admin['nom'] ?? '') . ' ' . ($admin['prenom'] ?? '')); ?></p>

                                <?php if (!empty($admin['pseudo'])): ?>
                                <p><strong><i class="fas fa-at"></i> Pseudo :</strong><br>
                                <?php echo htmlspecialchars($admin['pseudo']); ?></p>
                                <?php endif; ?>

                                <p><strong><i class="fas fa-envelope"></i> Email :</strong><br>
                                <small><?php echo htmlspecialchars($admin['email'] ?? ''); ?></small></p>

                                <?php if (!empty($admin['date_naissance'])): ?>
                                <p><strong><i class="fas fa-birthday-cake"></i> Date de naissance :</strong><br>
                                <?php echo date('d/m/Y', strtotime($admin['date_naissance'])); ?></p>
                                <?php endif; ?>

                                <?php if (!empty($admin['date_inscription'])): ?>
                                <p><strong><i class="fas fa-calendar-plus"></i> Inscription :</strong><br>
                                <?php echo date('d/m/Y à H:i', strtotime($admin['date_inscription'])); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="d-grid gap-2">
                                <form method="POST" style="display: inline;" onsubmit="return confirmValidation('<?php echo htmlspecialchars($admin['pseudo'] ?: ($admin['nom'] ?? 'cet utilisateur')); ?>')">
                                    <input type="hidden" name="user_id" value="<?php echo (int)$admin['id']; ?>">
                                    <input type="hidden" name="action" value="valider">
                                    <button type="submit" class="btn btn-validate w-100">
                                        <i class="fas fa-check"></i> Valider l'inscription
                                    </button>
                                </form>

                                <form method="POST" style="display: inline;" onsubmit="return confirmRejection('<?php echo htmlspecialchars($admin['pseudo'] ?: ($admin['nom'] ?? 'cet utilisateur')); ?>')">
                                    <input type="hidden" name="user_id" value="<?php echo (int)$admin['id']; ?>">
                                    <input type="hidden" name="action" value="rejeter">
                                    <button type="submit" class="btn btn-reject w-100">
                                        <i class="fas fa-times"></i> Rejeter l'inscription
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmValidation(pseudo) {
            return confirm(`Êtes-vous sûr de vouloir VALIDER l'inscription de ${pseudo} en tant qu'administratif ?\n\nCette personne aura accès aux fonctions d'administration.`);
        }
        function confirmRejection(pseudo) {
            return confirm(`Êtes-vous sûr de vouloir REJETER l'inscription de ${pseudo} ?\n\n⚠️ ATTENTION : Cette action supprimera définitivement le compte !`);
        }
        window.addEventListener('load', function() {
            const cards = document.querySelectorAll('.validation-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'all 0.5s ease';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 150 + 300);
            });
        });
        setTimeout(function() {
            document.querySelectorAll('.alert .btn-close')?.forEach(btn => btn.click());
        }, 5000);
    </script>
</body>
</html>
