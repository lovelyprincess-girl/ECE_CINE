<?php
session_start();
require_once 'config.php'; // connexion PDO $conn

// Configuration du système de likes
$likes_system = [
    'table_exists' => false,
    'film_column' => 'id_film',
    'user_column' => 'id_utilisateur',
    'user_id' => null,
    'is_logged' => false
];

// Vérification de l'existence et structure de la table likes
try {
    $check_table = $conn->prepare("SHOW TABLES LIKE 'likes'");
    $check_table->execute();
    
    if ($check_table->rowCount() > 0) {
        // Table existe, vérifier structure
        $structure_query = $conn->prepare("DESCRIBE likes");
        $structure_query->execute();
        $columns_info = $structure_query->fetchAll(PDO::FETCH_ASSOC);
        $available_columns = array_column($columns_info, 'Field');
        
        // Déterminer colonnes film
        if (in_array('id_film', $available_columns)) {
            $likes_system['film_column'] = 'id_film';
        } elseif (in_array('film_id', $available_columns)) {
            $likes_system['film_column'] = 'film_id';
        } elseif (in_array('movie_id', $available_columns)) {
            $likes_system['film_column'] = 'movie_id';
        }
        
        // Déterminer colonnes utilisateur
        if (in_array('id_utilisateur', $available_columns)) {
            $likes_system['user_column'] = 'id_utilisateur';
        } elseif (in_array('user_id', $available_columns)) {
            $likes_system['user_column'] = 'user_id';
        } elseif (in_array('id_user', $available_columns)) {
            $likes_system['user_column'] = 'id_user';
        }
        
        // Vérifier que les colonnes nécessaires existent
        if (in_array($likes_system['film_column'], $available_columns) && 
            in_array($likes_system['user_column'], $available_columns)) {
            $likes_system['table_exists'] = true;
        }
    }
} catch (PDOException $e) {
    error_log("Erreur vérification table likes: " . $e->getMessage());
}

// Déterminer l'utilisateur actuel
if (isset($_SESSION['user_id'])) {
    $likes_system['user_id'] = $_SESSION['user_id'];
    $likes_system['is_logged'] = true;
} else {
    // Utilisateur anonyme basé sur IP + session
    $likes_system['user_id'] = 'anon_' . md5($_SERVER['REMOTE_ADDR'] . session_id());
    $likes_system['is_logged'] = false;
}

// Détection des colonnes de la table film
$film_columns = [
    'base' => "f.id, f.titre, f.realisateur, f.date_partage",
    'optional' => []
];

try {
    $columns_query = $conn->prepare("DESCRIBE film");
    $columns_query->execute();
    $film_structure = $columns_query->fetchAll(PDO::FETCH_ASSOC);
    $film_available_columns = array_column($film_structure, 'Field');
    
    // Détection image
    if (in_array('image_url', $film_available_columns)) {
        $film_columns['optional'][] = 'f.image_url';
    } elseif (in_array('affiche', $film_available_columns)) {
        $film_columns['optional'][] = 'f.affiche as image_url';
    } elseif (in_array('poster', $film_available_columns)) {
        $film_columns['optional'][] = 'f.poster as image_url';
    }
    
    // Détection vidéo
    $video_columns = ['film_url', 'trailer', 'url_trailer', 'trailer_url', 'video', 
                     'lien_video', 'url_video', 'video_path', 'fichier', 'path', 'lien', 'url'];
    
    foreach ($video_columns as $col) {
        if (in_array($col, $film_available_columns)) {
            $film_columns['optional'][] = "f.{$col} as video_url";
            break;
        }
    }
    
    // Construction de la requête
    $select_columns = $film_columns['base'];
    if (!empty($film_columns['optional'])) {
        $select_columns .= ', ' . implode(', ', $film_columns['optional']);
    }
    
    // Ajout du système de likes
    if ($likes_system['table_exists']) {
        $select_columns .= ', COALESCE(COUNT(l.id), 0) as total_likes';
        $select_columns .= ', COALESCE(MAX(CASE WHEN l.' . $likes_system['user_column'] . ' = :user_id THEN 1 ELSE 0 END), 0) as user_liked';
        
        $where_clause = in_array('valide', $film_available_columns) ? "WHERE f.valide = 1" : "";
        
        $sql = "SELECT {$select_columns} 
                FROM film f 
                LEFT JOIN likes l ON f.id = l.{$likes_system['film_column']} 
                {$where_clause} 
                GROUP BY f.id 
                ORDER BY f.date_partage DESC";
    } else {
        $select_columns .= ', 0 as total_likes, 0 as user_liked';
        $where_clause = in_array('valide', $film_available_columns) ? "WHERE f.valide = 1" : "";
        
        $sql = "SELECT {$select_columns} FROM film f {$where_clause} ORDER BY f.date_partage DESC";
    }
    
} catch (PDOException $e) {
    error_log("Erreur construction requête: " . $e->getMessage());
    // Requête de fallback
    $sql = "SELECT id, titre, realisateur, date_partage, 0 as total_likes, 0 as user_liked FROM film ORDER BY date_partage DESC";
    $likes_system['table_exists'] = false;
}

// Exécution de la requête
try {
    $stmt = $conn->prepare($sql);
    if ($likes_system['table_exists']) {
        $stmt->bindParam(':user_id', $likes_system['user_id']);
    }
    $stmt->execute();
    $films = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erreur exécution requête films: " . $e->getMessage());
    $films = [];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Films - ECE Ciné</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
<style>
  body {
    background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), 
                url('https://i.pinimg.com/474x/27/da/97/27da97815c0c6f03d457d4158095d014--cinema-party-home-movies.jpg') no-repeat center center fixed;
    background-size: cover;
    background-attachment: fixed;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: white;
    min-height: 100vh;
  }

  .main-title {
    text-align: center;
    margin-bottom: 40px;
    font-size: 2.5rem;
    font-weight: 700;
    text-shadow: 3px 3px 8px rgba(0,0,0,0.8);
    color: white !important;
    padding: 20px 0;
  }

  .film-card {
    margin-bottom: 25px;
    height: 100%;
  }

  .card {
    background: rgba(0,0,0,0.85);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 15px;
    overflow: hidden;
    transition: all 0.3s ease-in-out;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
  }

  .card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 15px 40px rgba(0,0,0,0.5);
    border-color: rgba(255,255,255,0.2);
  }

  .film-image {
    width: 100%;
    height: 200px;
    object-fit: cover;
    object-position: center;
    border-radius: 15px 15px 0 0;
  }

  .placeholder-image {
    width: 100%;
    height: 200px;
    background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 15px 15px 0 0;
    color: white;
    font-size: 3rem;
  }

  .card-body {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    padding: 20px;
  }

  .card-title {
    color: white !important;
    font-size: 1.4rem;
    font-weight: 600;
    margin-bottom: 10px;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
    line-height: 1.3;
  }

  .card-subtitle {
    color: #e0e0e0 !important;
    font-size: 1rem;
    margin-bottom: 8px;
    font-weight: 500;
  }

  .card-text {
    color: #cccccc !important;
    font-size: 0.9rem;
    margin-bottom: 15px;
    flex-grow: 1;
  }

  .likes-section {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 20px;
    background: rgba(0,0,0,0.3);
    border-top: 1px solid rgba(255,255,255,0.1);
    margin-top: auto;
  }

  .like-button {
    background: none;
    border: none;
    color: #ccc;
    font-size: 1.2rem;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    border-radius: 20px;
    position: relative;
  }

  .like-button:hover {
    background: rgba(255,255,255,0.1);
    color: #ff6b6b;
    transform: scale(1.05);
  }

  .like-button.liked {
    color: #ff6b6b;
    animation: heartBeat 0.6s ease-in-out;
  }

  .like-button.liked:hover {
    color: #ff5252;
  }

  .like-button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  .like-count {
    font-weight: 600;
    font-size: 1rem;
  }

  @keyframes heartBeat {
    0% { transform: scale(1); }
    25% { transform: scale(1.2); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
  }

  .like-pulse {
    animation: pulse 0.3s ease-in-out;
  }

  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
  }

  .video-container {
    border-radius: 0 0 15px 15px;
    overflow: hidden;
    background: rgba(0,0,0,0.9);
  }

  video {
    width: 100%;
    height: auto;
    max-height: 250px;
    outline: none;
  }

  .youtube-container {
    position: relative;
    width: 100%;
    height: 250px;
    overflow: hidden;
  }

  .youtube-container iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }

  .no-video {
    text-align: center;
    padding: 30px;
    color: #999;
    font-style: italic;
    background: rgba(0,0,0,0.5);
    border-radius: 8px;
    margin: 10px;
  }

  .btn-back {
    background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
    border: none;
    color: white;
    font-weight: 600;
    padding: 12px 30px;
    border-radius: 25px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 10px;
  }

  .btn-back:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.4);
    color: white;
    text-decoration: none;
  }

  .no-films {
    text-align: center;
    padding: 60px 20px;
    background: rgba(0,0,0,0.7);
    border-radius: 15px;
    margin: 40px 0;
  }

  .no-films i {
    font-size: 4rem;
    color: #666;
    margin-bottom: 20px;
  }

  .container-fluid {
    max-width: 1200px;
    margin: 0 auto;
  }

  .debug-info {
    background: rgba(0,0,0,0.8);
    color: #0f0;
    padding: 15px;
    margin: 20px 0;
    border-radius: 8px;
    font-family: 'Courier New', monospace;
    font-size: 0.9rem;
    display: none;
  }

  @media (max-width: 576px) {
    .main-title {
      font-size: 2rem;
      margin-bottom: 30px;
    }
    
    .card-title {
      font-size: 1.2rem;
    }
    
    .film-image, .placeholder-image {
      height: 150px;
    }
    
    video {
      max-height: 200px;
    }

    .likes-section {
      flex-direction: column;
      gap: 10px;
      text-align: center;
    }
  }

  @media (min-width: 577px) and (max-width: 768px) {
    .film-image, .placeholder-image {
      height: 180px;
    }
  }

  @media (min-width: 769px) {
    .film-image, .placeholder-image {
      height: 220px;
    }
  }
</style>
</head>
<body>
<div class="container-fluid py-4">
  <h1 class="main-title">
    <i class="fas fa-film"></i> Films ECE Ciné
  </h1>

  <!-- Debug Info (masqué par défaut) -->
  <div class="debug-info" id="debug-info">
    <strong>🔧 Debug Info:</strong><br>
    Table likes: <?= $likes_system['table_exists'] ? '✅ Active' : '❌ Inactive' ?><br>
    Utilisateur: <?= $likes_system['is_logged'] ? '👤 Connecté' : '👻 Anonyme' ?> (<?= htmlspecialchars($likes_system['user_id']) ?>)<br>
    Films trouvés: <?= count($films) ?><br>
    Colonnes: film=<?= $likes_system['film_column'] ?>, user=<?= $likes_system['user_column'] ?>
  </div>

  <?php if (empty($films)): ?>
    <div class="no-films">
      <i class="fas fa-film"></i>
      <h3>Aucun film disponible</h3>
      <p class="mb-0">Il n'y a actuellement aucun film à afficher.</p>
    </div>
  <?php else: ?>
    <div class="row g-4">
      <?php foreach ($films as $film): ?>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="film-card">
            <div class="card h-100">
              <?php if (isset($film['image_url']) && !empty($film['image_url'])): ?>
                <img src="<?= htmlspecialchars($film['image_url']) ?>" 
                     alt="Affiche de <?= htmlspecialchars($film['titre']) ?>" 
                     class="film-image"
                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                <div class="placeholder-image" style="display:none;">
                  <i class="fas fa-film"></i>
                </div>
              <?php else: ?>
                <div class="placeholder-image">
                  <i class="fas fa-film"></i>
                </div>
              <?php endif; ?>
              
              <div class="card-body">
                <h5 class="card-title">
                  <i class="fas fa-movie-camera me-2"></i>
                  <?= htmlspecialchars($film['titre']) ?>
                </h5>
                
                <h6 class="card-subtitle">
                  <i class="fas fa-user-tie me-2"></i>
                  <?= htmlspecialchars($film['realisateur']) ?>
                </h6>
                
                <p class="card-text">
                  <small>
                    <i class="fas fa-calendar me-2"></i>
                    Partagé le <?= date('d/m/Y', strtotime($film['date_partage'])) ?>
                  </small>
                </p>
                
                <?php if (isset($film['video_url']) && !empty($film['video_url'])): ?>
                  <div class="video-container">
                    <?php 
                    if (strpos($film['video_url'], 'youtube.com') !== false || strpos($film['video_url'], 'youtu.be') !== false): 
                        preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $film['video_url'], $matches);
                        $youtube_id = isset($matches[1]) ? $matches[1] : '';
                        if ($youtube_id): ?>
                          <div class="youtube-container">
                            <iframe 
                              width="100%" 
                              height="250" 
                              src="https://www.youtube.com/embed/<?= $youtube_id ?>" 
                              frameborder="0" 
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                              allowfullscreen>
                            </iframe>
                          </div>
                        <?php else: ?>
                          <div class="no-video">
                            <i class="fas fa-exclamation-triangle mb-2"></i><br>
                            Lien YouTube invalide
                          </div>
                        <?php endif; ?>
                    <?php else: ?>
                      <video controls preload="metadata" controlsList="nodownload noremoteplayback" disablePictureInPicture>
                        <source src="<?= htmlspecialchars($film['video_url']) ?>" type="video/mp4">
                        <source src="<?= htmlspecialchars($film['video_url']) ?>" type="video/webm">
                        <source src="<?= htmlspecialchars($film['video_url']) ?>" type="video/ogg">
                        <p>Votre navigateur ne supporte pas la lecture vidéo HTML5.</p>
                      </video>
                    <?php endif; ?>
                  </div>
                <?php else: ?>
                  <div class="no-video">
                    <i class="fas fa-info-circle mb-2"></i><br>
                    Pas de vidéo disponible
                  </div>
                <?php endif; ?>
              </div>
              
              <!-- Section des likes -->
              <?php if ($likes_system['table_exists']): ?>
              <div class="likes-section">
                <div class="like-count">
                  <i class="fas fa-heart me-1"></i>
                  <span id="count-<?= $film['id'] ?>"><?= $film['total_likes'] ?></span>
                  <span id="label-<?= $film['id'] ?>"><?= $film['total_likes'] > 1 ? 'likes' : 'like' ?></span>
                </div>
                
                <button 
                  class="like-button <?= $film['user_liked'] ? 'liked' : '' ?>" 
                  data-film-id="<?= $film['id'] ?>"
                  data-liked="<?= $film['user_liked'] ?>"
                  onclick="toggleLike(<?= $film['id'] ?>, this)"
                  id="btn-<?= $film['id'] ?>">
                  <i class="<?= $film['user_liked'] ? 'fas' : 'far' ?> fa-heart" id="icon-<?= $film['id'] ?>"></i>
                  <span id="text-<?= $film['id'] ?>"><?= $film['user_liked'] ? 'Aimé' : 'Aimer' ?></span>
                </button>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  
  <div class="text-center mt-5">
    <a href="dashboard.php" class="btn-back">
      <i class="fas fa-arrow-left"></i>
      Retour au tableau de bord
    </a>
    
    <!-- Bouton debug -->
    <button onclick="toggleDebug()" class="btn btn-outline-light ms-3" style="font-size: 0.8rem;">
      🔧 Debug
    </button>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Configuration globale
const LIKES_CONFIG = {
    enabled: <?= $likes_system['table_exists'] ? 'true' : 'false' ?>,
    userId: '<?= htmlspecialchars($likes_system['user_id']) ?>',
    isLogged: <?= $likes_system['is_logged'] ? 'true' : 'false' ?>
};

// Fonction pour afficher/masquer le debug
function toggleDebug() {
    const debugInfo = document.getElementById('debug-info');
    debugInfo.style.display = debugInfo.style.display === 'none' ? 'block' : 'none';
}

// Fonction principale pour gérer les likes
function toggleLike(filmId, button) {
    if (!LIKES_CONFIG.enabled) {
        alert('Le système de likes n\'est pas disponible');
        return;
    }
    
    console.log('🚀 toggleLike - Film:', filmId, 'Config:', LIKES_CONFIG);
    
    const countSpan = document.getElementById(`count-${filmId}`);
    const labelSpan = document.getElementById(`label-${filmId}`);
    const icon = document.getElementById(`icon-${filmId}`);
    const text = document.getElementById(`text-${filmId}`);
    const isLiked = button.dataset.liked === '1';
    
    // État avant
    console.log('📊 État avant:', {
        filmId: filmId,
        isLiked: isLiked,
        currentCount: countSpan.textContent,
        buttonClasses: button.className
    });
    
    // Désactiver le bouton
    button.disabled = true;
    button.style.opacity = '0.6';
    
    // Données à envoyer
    const requestData = {
        film_id: parseInt(filmId),
        action: isLiked ? 'unlike' : 'like',
        user_id: LIKES_CONFIG.userId
    };
    
    console.log('📤 Données envoyées:', requestData);
    
    // Requête AJAX
    fetch('likes_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(requestData)
    })
    .then(response => {
        console.log('📡 Status:', response.status, response.statusText);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('📦 Réponse:', data);
        
        if (data.success) {
            // Nouveau comptage
            const newCount = data.total_likes !== undefined ? 
                           parseInt(data.total_likes) : 
                           (parseInt(countSpan.textContent) + (isLiked ? -1 : 1));
            
            // Mettre à jour l'interface
            countSpan.textContent = newCount;
            labelSpan.textContent = newCount > 1 ? 'likes' : 'like';
            
            if (isLiked) {
                // Retirer le like
                button.classList.remove('liked');
                icon.className = 'far fa-heart';
                text.textContent = 'Aimer';
                button.dataset.liked = '0';
                console.log('💔 Like retiré');
            } else {
                // Ajouter le like
                button.classList.add('liked');
                icon.className = 'fas fa-heart';
                text.textContent = 'Aimé';
                button.dataset.liked = '1';
                
                // Animation
                button.classList.add('like-pulse');
                setTimeout(() => button.classList.remove('like-pulse'), 300);
                console.log('❤️ Like ajouté');
            }
            
            console.log('✅ Interface mise à jour. Nouveau count:', newCount);
            
        } else {
            console.error('❌ Erreur serveur:', data.message);
            showMessage('Erreur: ' + (data.message || 'Erreur inconnue'), 'error');
        }
    })
    .catch(error => {
        console.error('💥 Erreur:', error);
        showMessage('Erreur de connexion: ' + error.message, 'error');
    })
    .finally(() => {
        // Réactiver le bouton
        button.disabled = false;
        button.style.opacity = '1';
        console.log('🔓 Bouton réactivé');
    });
}

// Fonction pour afficher des messages
function showMessage(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : 'alert-info';
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alert);
    
    // Supprimer automatiquement après 5 secondes
    setTimeout(() => {
        if (alert.parentNode) {
            alert.remove();
        }
    }, 5000);
}

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎬 Page chargée. Config likes:', LIKES_CONFIG);
    
    // Lazy loading pour les vidéos
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
        video.addEventListener('loadedmetadata', function() {
            this.style.opacity = '1';
        });
    });

    // Gestion d'erreur pour les images
    const images = document.querySelectorAll('.film-image');
    images.forEach(img => {
        img.addEventListener('error', function() {
            this.style.display = 'none';
            const placeholder = this.nextElementSibling;
            if (placeholder && placeholder.classList.contains('placeholder-image')) {
                placeholder.style.display = 'flex';
            }
        });
    });

    // Animation au scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    });

    document.querySelectorAll('.film-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';