function toggleLike(filmId) {
    console.log('🔄 toggleLike appelée pour film:', filmId);
    
    const button = document.querySelector(`[data-film-id="${filmId}"]`);
    const countSpan = document.getElementById(`count-${filmId}`);
    const isLiked = button.dataset.liked === '1';
    
    console.log('📊 État actuel:', { isLiked, count: countSpan.textContent });
    
    // Désactiver le bouton pendant la requête
    button.disabled = true;
    
    // Requête AJAX avec debug
    fetch('likes_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            film_id: filmId,
            action: isLiked ? 'unlike' : 'like'
        })
    })
    .then(response => {
        console.log('📡 Réponse reçue:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('📦 Données reçues:', data);
        
        if (data.success) {
            const newCount = data.total_likes !== undefined ? data.total_likes : 
                            (parseInt(countSpan.textContent) + (isLiked ? -1 : 1));
            
            countSpan.textContent = newCount;
            
            // Mettre à jour le bouton
            const icon = button.querySelector('i');
            const span = button.querySelector('span');
            
            if (isLiked) {
                // Retirer le like
                button.classList.remove('liked');
                icon.className = 'far fa-heart';
                span.textContent = 'Aimer';
                button.dataset.liked = '0';
                console.log('💔 Like retiré');
            } else {
                // Ajouter le like
                button.classList.add('liked');
                icon.className = 'fas fa-heart';
                span.textContent = 'Aimé';
                button.dataset.liked = '1';
                
                // Animation
                button.classList.add('like-pulse');
                setTimeout(() => button.classList.remove('like-pulse'), 300);
                console.log('❤️ Like ajouté');
            }
            
            // Mettre à jour le texte du compteur
            const countText = button.parentElement.querySelector('.like-count');
            const textNodes = Array.from(countText.childNodes).filter(node => node.nodeType === 3);
            if (textNodes.length > 0) {
                textNodes[textNodes.length - 1].textContent = newCount > 1 ? 'likes' : 'like';
            }
        } else {
            console.error('❌ Erreur serveur:', data.message);
            alert('Erreur: ' + data.message);
        }
    })
    .catch(error => {
        console.error('💥 Erreur réseau:', error);
        alert('Erreur de connexion');
    })
    .finally(() => {
        // Réactiver le bouton
        button.disabled = false;
        console.log('🔓 Bouton réactivé');
    });
}