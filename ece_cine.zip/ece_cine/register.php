<?php
require_once 'config.php';

$message = '';
$message_type = 'error'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération sécurisée des données du formulaire
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $pseudo = trim($_POST['pseudo'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';
    $date_naissance = $_POST['date_naissance'] ?? '';
    $role = $_POST['role'] ?? '';

    // Vérification des champs obligatoires
    if (empty($nom) || empty($prenom) || empty($email) || empty($mot_de_passe) || empty($date_naissance) || empty($role)) {
        $message = "Merci de remplir tous les champs obligatoires.";
        $message_type = 'error';
    } else {
        // Validation de l'email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = "L'adresse email n'est pas valide.";
            $message_type = 'error';
        } 
        // Validation du mot de passe (minimum 6 caractères)
        else if (strlen($mot_de_passe) < 6) {
            $message = "Le mot de passe doit contenir au moins 6 caractères.";
            $message_type = 'error';
        }
        // Validation de la date de naissance
        else if (!DateTime::createFromFormat('Y-m-d', $date_naissance)) {
            $message = "La date de naissance n'est pas valide.";
            $message_type = 'error';
        }
        // Validation du rôle
        else if (!in_array($role, ['Etudiant', 'Enseignant', 'Administratif'])) {
            $message = "Le rôle sélectionné n'est pas valide.";
            $message_type = 'error';
        }
        else {
            try {
                // Vérifier si l'email existe déjà
                $check_sql = "SELECT COUNT(*) FROM utilisateur WHERE email = ?";
                $check_stmt = $conn->prepare($check_sql);
                
                if (!$check_stmt) {
                    throw new PDOException("Erreur lors de la préparation de la requête de vérification");
                }
                
                $check_stmt->execute([$email]);
                
                if ($check_stmt->fetchColumn() > 0) {
                    $message = "Cet email est déjà utilisé. Veuillez en choisir un autre.";
                    $message_type = 'error';
                } else {
                    // Hashage du mot de passe
                    $mot_de_passe_hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);

                    // Préparation et exécution de la requête d'insertion
                    $sql = "INSERT INTO utilisateur (nom, prenom, pseudo, email, mot_de_passe, date_naissance, statut, role) 
                            VALUES (?, ?, ?, ?, ?, ?, 'actif', ?)";
                    $stmt = $conn->prepare($sql);
                    
                    if (!$stmt) {
                        throw new PDOException("Erreur lors de la préparation de la requête d'insertion");
                    }

                    if ($stmt->execute([$nom, $prenom, $pseudo, $email, $mot_de_passe_hash, $date_naissance, $role])) {
                        // Redirection vers login.php après inscription réussie
                        header('Location: login.php?inscription=success');
                        exit();
                    } else {
                        $errorInfo = $stmt->errorInfo();
                        throw new PDOException("Erreur lors de l'insertion : " . $errorInfo[2]);
                    }
                }
            } catch (PDOException $e) {
                error_log("Erreur base de données inscription: " . $e->getMessage());
                $message = "Une erreur est survenue lors de l'inscription. Veuillez réessayer.";
                $message_type = 'error';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - ECE Ciné</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://i.pinimg.com/474x/27/da/97/27da97815c0c6f03d457d4158095d014--cinema-party-home-movies.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            width: 100%;
            max-width: 450px;
            animation: slideUp 0.6s ease-out;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            background: #000000;
            color: white;
            text-align: center;
            padding: 40px 20px;
        }

        .header h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .header p {
            opacity: 0.9;
            font-size: 16px;
        }

        .form-container {
            padding: 40px;
        }

        .message {
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-weight: 500;
            text-align: center;
            animation: fadeIn 0.5s ease-in;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .required {
            color: #ff6b6b;
        }

        input[type="text"], 
        input[type="email"], 
        input[type="password"], 
        input[type="date"],
        select {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e8ed;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background-color: #fafbfc;
        }

        input[type="text"]:focus, 
        input[type="email"]:focus, 
        input[type="password"]:focus, 
        input[type="date"]:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
            background-color: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        .submit-btn {
            width: 100%;
            background: #000000;
            color: white;
            border: none;
            padding: 18px;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }

        .submit-btn:active {
            transform: translateY(-1px);
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid #e1e8ed;
        }

        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .login-link a:hover {
            color: #764ba2;
        }

        .shake {
            animation: shake 0.6s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }

        @media (max-width: 480px) {
            .container {
                margin: 10px;
                border-radius: 15px;
            }
            
            .form-container {
                padding: 30px 25px;
            }
            
            .header {
                padding: 30px 20px;
            }
            
            .header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎬 ECE Ciné</h1>
            <p>Créer votre compte</p>
        </div>

        <div class="form-container">
            <?php if ($message): ?>
                <div class="message <?= $message_type ?> <?= $message_type === 'error' ? 'shake' : '' ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="nom">Nom <span class="required">*</span></label>
                    <input type="text" id="nom" name="nom" required 
                           placeholder="Votre nom"
                           value="<?= isset($_POST['nom']) ? htmlspecialchars($_POST['nom']) : '' ?>" />
                </div>

                <div class="form-group">
                    <label for="prenom">Prénom <span class="required">*</span></label>
                    <input type="text" id="prenom" name="prenom" required 
                           placeholder="Votre prénom"
                           value="<?= isset($_POST['prenom']) ? htmlspecialchars($_POST['prenom']) : '' ?>" />
                </div>

                <div class="form-group">
                    <label for="pseudo">Pseudo</label>
                    <input type="text" id="pseudo" name="pseudo" 
                           placeholder="Votre pseudo (optionnel)"
                           value="<?= isset($_POST['pseudo']) ? htmlspecialchars($_POST['pseudo']) : '' ?>" />
                </div>

                <div class="form-group">
                    <label for="email">Email <span class="required">*</span></label>
                    <input type="email" id="email" name="email" required 
                           placeholder="votre@email.com"
                           value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" />
                </div>

                <div class="form-group">
                    <label for="mot_de_passe">Mot de passe <span class="required">*</span></label>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" required 
                           placeholder="••••••••" minlength="6" />
                </div>

                <div class="form-group">
                    <label for="date_naissance">Date de naissance <span class="required">*</span></label>
                    <input type="date" id="date_naissance" name="date_naissance" required 
                           value="<?= isset($_POST['date_naissance']) ? htmlspecialchars($_POST['date_naissance']) : '' ?>" />
                </div>

                <div class="form-group">
                    <label for="role">Rôle <span class="required">*</span></label>
                    <select name="role" id="role" required>
                        <option value="">-- Choisissez un rôle --</option>
                        <option value="Etudiant" <?= (isset($_POST['role']) && $_POST['role'] === 'Etudiant') ? 'selected' : '' ?>>Étudiant</option>
                        <option value="Enseignant" <?= (isset($_POST['role']) && $_POST['role'] === 'Enseignant') ? 'selected' : '' ?>>Enseignant</option>
                        <option value="Administratif" <?= (isset($_POST['role']) && $_POST['role'] === 'Administratif') ? 'selected' : '' ?>>Administratif</option>
                    </select>
                </div>

                <button type="submit" class="submit-btn">S'inscrire</button>
            </form>

            <div class="login-link">
                <p>Déjà inscrit ? <a href="login.php">Se connecter</a></p>
            </div>
        </div>
    </div>
</body>
</html>