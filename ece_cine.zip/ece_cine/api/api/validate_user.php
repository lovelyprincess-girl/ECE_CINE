<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

try {
    // Connexion à votre base de données
    $host = 'localhost';
    $dbname = 'ece_cine';
    $username = 'root';
    $password = '';
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Récupérer les données POST
    $data = json_decode(file_get_contents('php://input'), true);
    $userId = $data['user_id'];
    $approved = $data['approved'];
    $compteValide = $data['compte_valide']; // 0 = validé, 2 = refusé
    
    // Mettre à jour le statut de l'utilisateur
    $stmt = $pdo->prepare("UPDATE utilisateurs SET compte_valide = ? WHERE id = ?");
    $stmt->execute([$compteValide, $userId]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Utilisateur mis à jour',
        'user_id' => $userId,
        'compte_valide' => $compteValide
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>