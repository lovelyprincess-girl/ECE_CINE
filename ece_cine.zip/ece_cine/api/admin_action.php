<?php
session_start();
require_once "config.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='Admin'){
    echo json_encode(['success'=>false,'message'=>'Accès refusé']);
    exit();
}

$data = json_decode(file_get_contents('php://input'),true);
$userId = (int)$data['id'];
$action = $data['action'];

switch($action){
    case 'accept':
        $sql = "UPDATE utilisateurs SET compte_valide=1 WHERE id=$userId";
        $msg = "Utilisateur accepté et compte activé";
        break;
    case 'refuse':
        $sql = "UPDATE utilisateurs SET compte_valide=0 WHERE id=$userId";
        $msg = "Utilisateur refusé";
        break;
    case 'delete':
        $sql = "DELETE FROM utilisateurs WHERE id=$userId";
        $msg = "Utilisateur radié avec succès";
        break;
    default:
        echo json_encode(['success'=>false,'message'=>'Action invalide']);
        exit();
}

if($conn->query($sql)){
    echo json_encode(['success'=>true,'message'=>$msg]);
} else {
    echo json_encode(['success'=>false,'message'=>'Erreur BDD']);
}
?>
