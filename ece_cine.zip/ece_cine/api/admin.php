<?php
session_start();
require_once "config.php";

// Vérifier que l'utilisateur est admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Récupérer tous les utilisateurs 
$sql = "SELECT id, nom, prenom, pseudo, email, date_naissance, role AS statut, compte_valide
        FROM utilisateurs";
$result = $conn->query($sql);
$users = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Gestion Utilisateurs</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .status-badge {padding: 0.25rem 0.75rem; border-radius: 15px; font-size: 0.8rem; font-weight: bold;}
        .status-pending {background: #ffc107; color: #000;}
        .status-active {background: #28a745; color: #fff;}
        .status-refused {background: #dc3545; color: #fff;}
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4 text-center">Administration - Gestion des utilisateurs</h2>

    <!-- Filtres -->
    <div class="mb-3 text-center">
        <button class="btn btn-outline-dark me-2" onclick="filterUsers('all')">Tous</button>
        <button class="btn btn-outline-primary me-2" onclick="filterUsers('Etudiant')">Étudiants</button>
        <button class="btn btn-outline-success me-2" onclick="filterUsers('Enseignant')">Enseignants</button>
    </div>

    <div id="alertZone"></div>

    <div class="row" id="usersContainer">
        <?php foreach($users as $user): ?>
            <div class="col-md-6 mb-3 user-card" data-role="<?= $user['statut'] ?>" data-valid="<?= $user['compte_valide'] ?>">
                <div class="card">
                    <div class="card-body">
                        <h5><?= htmlspecialchars($user['nom'] . " " . $user['prenom']) ?></h5>
                        <p>
                            <strong>Pseudo :</strong> <?= htmlspecialchars($user['pseudo'] ?: "Non renseigné") ?><br>
                            <strong>Email :</strong> <?= htmlspecialchars($user['email']) ?><br>
                            <strong>Statut :</strong> <span class="status-badge <?= $user['compte_valide']==-1?'status-pending':($user['compte_valide']==1?'status-active':'status-refused') ?>">
                                <?= $user['compte_valide']==-1?'En attente':($user['compte_valide']==1?'Actif':'Refusé') ?>
                            </span><br>
                            <strong>Date de naissance :</strong> <?= htmlspecialchars($user['date_naissance']) ?>
                        </p>
                        <div class="btn-group">
                            <?php if($user['compte_valide'] == -1): ?>
                                <button class="btn btn-success btn-sm" onclick="updateUser(<?= $user['id'] ?>,1)">Accepter</button>
                                <button class="btn btn-danger btn-sm" onclick="updateUser(<?= $user['id'] ?>,0)">Refuser</button>
                            <?php endif; ?>
                            <?php if($user['compte_valide'] == 1): ?>
                                <button class="btn btn-warning btn-sm" onclick="deleteUser(<?= $user['id'] ?>)">Radier</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
function showAlert(message, type='info') {
    const alertZone = document.getElementById('alertZone');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    alertZone.appendChild(alert);
    setTimeout(()=>alert.remove(),8000);
}

function filterUsers(role) {
    document.querySelectorAll('.user-card').forEach(card=>{
        if(role==='all' || card.dataset.role===role) card.style.display='block';
        else card.style.display='none';
    });
}

function updateUser(userId, approve) {
    if(!confirm(approve ? "Accepter cet utilisateur ?" : "Refuser cet utilisateur ?")) return;
    fetch('admin_actions.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:userId,action:approve? 'accept':'refuse'})
    })
    .then(res=>res.json())
    .then(data=>{
        showAlert(data.message, data.success?'success':'danger');
        if(data.success) location.reload();
    })
    .catch(err=>console.error(err));
}

function deleteUser(userId) {
    if(!confirm("Voulez-vous vraiment radier cet utilisateur ?")) return;
    fetch('admin_actions.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:userId,action:'delete'})
    })
    .then(res=>res.json())
    .then(data=>{
        showAlert(data.message, data.success?'success':'danger');
        if(data.success) location.reload();
    })
    .catch(err=>console.error(err));
}
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
