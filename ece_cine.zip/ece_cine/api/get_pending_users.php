<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

try {
    $host = 'localhost';
    $dbname = 'ece_cine'; 
    $username = 'root';   
    $password = '';       
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Récupérer les utilisateurs en attente
    $stmt = $pdo->prepare("
        SELECT id, nom, prenom, pseudo, email, date_naissance, statut, role, photo, date_inscription, compte_valide 
        FROM utilisateurs 
        WHERE valide = 1 
        ORDER BY date_inscription DESC
    ");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>