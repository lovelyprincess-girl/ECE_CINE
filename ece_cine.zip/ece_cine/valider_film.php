<?php
session_start();
require 'config.php';

// 🔒 Vérification rôle (admin, administratif et enseignants autorisés)
if (!isset($_SESSION['user']['role']) || !in_array(strtolower($_SESSION['user']['role']), ['admin', 'administratif', 'enseignant'])) {
    die("Accès refusé : seuls les administrateurs, les utilisateurs administratifs et les enseignants peuvent accéder à cette page.");
}

// ✅ Traitement validation / refus pour films
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['film_id'])) {
    $film_id = intval($_POST['film_id']);
    if (isset($_POST['valider_film'])) {
        $stmt = $conn->prepare("UPDATE film SET valide = 1 WHERE id = ?");
        $stmt->execute([$film_id]);
    } elseif (isset($_POST['refuser_film'])) {
        $stmt = $conn->prepare("UPDATE film SET valide = 0 WHERE id = ?");
        $stmt->execute([$film_id]);
    }
}

// 🔍 Récupérer les films en attente (valide = 0)
$stmtFilms = $conn->prepare("SELECT * FROM film WHERE valide = 0");
$stmtFilms->execute();
$films = $stmtFilms;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valider Films - ECE Ciné</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('https://i.pinimg.com/474x/27/da/97/27da97815c0c6f03d457d4158095d014--cinema-party-home-movies.jpg');
            background-size: cover;
            background-attachment: fixed;
            color: white;
            min-height: 100vh;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(0,0,0,0.8);
            padding: 1rem 2rem;
            margin-bottom: 2rem;
            border-radius: 10px;
        }

        .logo {
            font-size: 2rem;
            font-weight: bold;
            color: #ffffff;
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 0.5rem;
        }

        .user-icon {
            font-size: 1.8rem;
            color: #fff;
        }

        .main-content {
            background: rgba(0,0,0,0.8);
            border-radius: 15px;
            padding: 2rem;
            margin: 2rem auto;
            max-width: 1200px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            color: white;
        }

        th, td {
            border: 1px solid rgba(255,255,255,0.2);
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: rgba(0,0,0,0.5);
        }

        .btn-approve {
            background: linear-gradient(45deg, #28a745, #20c997);
            border: none;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .btn-deny {
            background: linear-gradient(45deg, #dc3545, #e50914);
            border: none;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .btn-approve:hover, .btn-deny:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.4);
            color: white;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 0.85rem;
            }
            .header {
                flex-direction: column;
                text-align: center;
            }
            .user-icon {
                margin-top: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <div class="header">
        <div class="logo"><i class="fa fa-film"></i> ECE Ciné</div>
        <div class="user-icon"><i class="fa fa-user-circle"></i></div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <h1 class="text-center mb-4">Films en attente</h1>

        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Réalisateur</th>
                    <th>Date de partage</th>
                    <th>Theme</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($films && $films->rowCount() > 0): ?>
                    <?php while($film = $films->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?= htmlspecialchars($film['titre']) ?></td>
                            <td><?= htmlspecialchars($film['realisateur']) ?></td>
                            <td><?= htmlspecialchars($film['date_partage']) ?></td>
                            <td><?= htmlspecialchars($film['theme']) ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="film_id" value="<?= $film['id'] ?>">
                                    <button type="submit" name="valider_film" class="btn-approve"><i class="fa fa-check"></i> Valider</button>
                                </form>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="film_id" value="<?= $film['id'] ?>">
                                    <button type="submit" name="refuser_film" class="btn-deny"><i class="fa fa-times"></i> Refuser</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">Aucun film en attente.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
