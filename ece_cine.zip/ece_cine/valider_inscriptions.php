<?php
session_start();
require 'config.php';

// 🔒 Vérification rôle (admin et administratif autorisés)
if (!isset($_SESSION['user']['role']) || !in_array(strtolower($_SESSION['user']['role']), ['admin','administratif'])) {
    die("Accès refusé : seuls les administrateurs et les utilisateurs administratifs peuvent accéder à cette page.");
}

// ✅ Traitement validation / refus
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    if (isset($_POST['valider'])) {
        $stmt = $conn->prepare("UPDATE utilisateur SET valide = 1 WHERE id = ?");
        $stmt->execute([$id]);
    } elseif (isset($_POST['refuser'])) {
        $stmt = $conn->prepare("UPDATE utilisateur SET valide = 0 WHERE id = ?");
        $stmt->execute([$id]);
    }
}

// 🔍 Récupérer les utilisateurs en attente sauf les administratifs
$stmt = $conn->prepare("SELECT * FROM utilisateur WHERE valide = -1 AND role != 'administratif'");
$stmt->execute();
$result = $stmt;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valider Inscriptions - ECE Ciné</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('https://i.pinimg.com/474x/27/da/97/27da97815c0c6f03d457d4158095d014--cinema-party-home-movies.jpg');
            background-size: cover;
            background-attachment: fixed;
            color: white;
            min-height: 100vh;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(0,0,0,0.8);
            padding: 1rem 2rem;
            margin-bottom: 2rem;
            border-radius: 10px;
        }

        .logo {
            font-size: 2rem;
            font-weight: bold;
            color: #ffffff; /* Texte en blanc */
            display: flex;
            align-items: center;
        }

        .logo i {
            margin-right: 0.5rem; /* espace entre icône et texte */
        }

        .user-icon {
            font-size: 1.8rem;
            color: #fff;
        }

        .main-content {
            background: rgba(0,0,0,0.8);
            border-radius: 15px;
            padding: 2rem;
            margin: 2rem auto;
            max-width: 1000px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            color: white;
        }

        th, td {
            border: 1px solid rgba(255,255,255,0.2);
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: rgba(0,0,0,0.5);
        }

        .btn-approve {
            background: linear-gradient(45deg, #28a745, #20c997);
            border: none;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .btn-approve:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
            color: white;
        }

        .btn-deny {
            background: linear-gradient(45deg, #dc3545, #e50914);
            border: none;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .btn-deny:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(229, 9, 20, 0.4);
            color: white;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 0.85rem;
            }
            .header {
                flex-direction: column;
                text-align: center;
            }
            .user-icon {
                margin-top: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <div class="header">
        <div class="logo">
            <i class="fa fa-film"></i> ECE Ciné
        </div>
        <div class="user-icon"><i class="fa fa-user-circle"></i></div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <h1 class="text-center mb-4">Validation des inscriptions</h1>

        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Rôle</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->rowCount() > 0): ?>
                    <?php while($row = $result->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nom']) ?></td>
                            <td><?= htmlspecialchars($row['prenom']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= htmlspecialchars($row['role']) ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <button type="submit" name="valider" class="btn-approve"><i class="fa fa-check"></i> Valider</button>
                                </form>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <button type="submit" name="refuser" class="btn-deny"><i class="fa fa-times"></i> Refuser</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">Aucun utilisateur en attente.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
