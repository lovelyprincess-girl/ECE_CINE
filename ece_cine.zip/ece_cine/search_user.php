<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$host = 'localhost';
$dbname = 'ece_cine'; 
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur de connexion à la base de données']);
    exit;
}

// Récupérer les données POST
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['email']) || empty($input['email'])) {
    echo json_encode(['success' => false, 'message' => 'Email requis']);
    exit;
}

$email = trim($input['email']);

try {
    // Rechercher l'utilisateur dans la base de données
    $stmt = $pdo->prepare("SELECT id, nom, prenom, pseudo, email, statut, date_inscription, compte_valide 
                          FROM utilisateur 
                          WHERE email = :email AND compte_valide = 1");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo json_encode([
            'success' => true, 
            'user' => $user,
            'message' => 'Utilisateur trouvé'
        ]);
    } else {
        // Vérifier si l'utilisateur existe mais n'est pas validé
        $stmt = $pdo->prepare("SELECT id FROM utilisateur WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $exists = $stmt->fetch();
        
        if ($exists) {
            echo json_encode(['success' => false, 'message' => 'Utilisateur trouvé mais compte non validé']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Aucun utilisateur trouvé avec cette adresse email']);
        }
    }
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de la recherche']);
}
?>