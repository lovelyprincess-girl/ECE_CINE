<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

// Gérer l'identification utilisateur 
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    // Pour les utilisateurs non connectés, utiliser l'IP + session ID
    $user_id = 'anonymous_' . md5($_SERVER['REMOTE_ADDR'] . session_id());
}

// Lire les données JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['film_id']) || !isset($input['action'])) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit;
}

$film_id = (int)$input['film_id'];
$action = $input['action'];

// Vérifier que le film existe
try {
    $check_film = $conn->prepare("SELECT id FROM film WHERE id = :film_id");
    $check_film->bindParam(':film_id', $film_id, PDO::PARAM_INT);
    $check_film->execute();
    
    if ($check_film->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Film non trouvé']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur de vérification du film']);
    exit;
}

// Déterminer la structure de la table likes
$likes_film_column = 'id_film';
$likes_user_column = 'id_utilisateur';

try {
    // Vérifier la structure de la table likes
    $likes_columns_query = "DESCRIBE likes";
    $likes_columns_stmt = $conn->prepare($likes_columns_query);
    $likes_columns_stmt->execute();
    $likes_columns_info = $likes_columns_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $likes_available_columns = array_column($likes_columns_info, 'Field');
    
    // Déterminer le nom de la colonne pour l'ID du film
    if (in_array('id_film', $likes_available_columns)) {
        $likes_film_column = 'id_film';
    } elseif (in_array('film_id', $likes_available_columns)) {
        $likes_film_column = 'film_id';
    } elseif (in_array('movie_id', $likes_available_columns)) {
        $likes_film_column = 'movie_id';
    }
    
    // Déterminer le nom de la colonne utilisateur
    if (in_array('id_utilisateur', $likes_available_columns)) {
        $likes_user_column = 'id_utilisateur';
    } elseif (in_array('user_id', $likes_available_columns)) {
        $likes_user_column = 'user_id';
    } elseif (in_array('id_user', $likes_available_columns)) {
        $likes_user_column = 'id_user';
    } elseif (in_array('utilisateur_id', $likes_available_columns)) {
        $likes_user_column = 'utilisateur_id';
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur de structure de table']);
    exit;
}

try {
    if ($action === 'like') {
        // Vérifier si l'utilisateur a déjà liké ce film
        $check_like = $conn->prepare("SELECT id FROM likes WHERE $likes_film_column = :film_id AND $likes_user_column = :user_id");
        $check_like->bindParam(':film_id', $film_id, PDO::PARAM_INT);
        $check_like->bindParam(':user_id', $user_id);
        $check_like->execute();
        
        if ($check_like->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Film déjà liké']);
            exit;
        }
        
        // Ajouter le like
        $add_like = $conn->prepare("INSERT INTO likes ($likes_film_column, $likes_user_column, date_like) VALUES (:film_id, :user_id, NOW())");
        $add_like->bindParam(':film_id', $film_id, PDO::PARAM_INT);
        $add_like->bindParam(':user_id', $user_id);
        $add_like->execute();
        
        echo json_encode(['success' => true, 'message' => 'Like ajouté']);
        
    } elseif ($action === 'unlike') {
        // Retirer le like
        $remove_like = $conn->prepare("DELETE FROM likes WHERE $likes_film_column = :film_id AND $likes_user_column = :user_id");
        $remove_like->bindParam(':film_id', $film_id, PDO::PARAM_INT);
        $remove_like->bindParam(':user_id', $user_id);
        $remove_like->execute();
        
        echo json_encode(['success' => true, 'message' => 'Like retiré']);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'Action invalide']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur de base de données: ' . $e->getMessage()]);
}
?>